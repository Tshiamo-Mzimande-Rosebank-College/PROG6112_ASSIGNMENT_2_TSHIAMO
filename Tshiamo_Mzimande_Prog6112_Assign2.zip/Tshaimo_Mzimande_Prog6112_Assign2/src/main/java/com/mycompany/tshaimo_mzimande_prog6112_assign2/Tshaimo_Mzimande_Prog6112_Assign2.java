package com.mycompany.tshaimo_mzimande_prog6112_assign2;

import javax.swing.*;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class Tshaimo_Mzimande_Prog6112_Assign2 {

    public static void main(String[] args) {
        Console.begin();
    }

    // Common contract every rescue type must honour.
    interface Lifecycle {
        String OPENED = "New Rescue";
        String ACTIVE = "Rescue in Progress";
        String WATCH  = "Under Observation";
        String CLOSED = "Rescue Completed";

        void begin();
        void close();
        String overview();
    }

    // Abstract base: shared fields, shared helper, abstract behaviour.
    static abstract class RescueRecord implements Lifecycle {

        private String reference, animal, species, region, ranger, stage;
        private int totalDays;
        private double dailyFee;

        RescueRecord(String reference, String animal, String species, String region,
                     String ranger, int totalDays, double dailyFee, String stage) {
            this.reference = reference;
            this.animal = animal;
            this.species = species;
            this.region = region;
            this.ranger = ranger;
            this.totalDays = totalDays;
            this.dailyFee = dailyFee;
            this.stage = stage;
        }

        String reference() { return reference; }
        String animal()    { return animal; }
        String species()   { return species; }
        String region()    { return region; }
        String ranger()    { return ranger; }
        String stage()     { return stage; }
        int totalDays()    { return totalDays; }
        double dailyFee()  { return dailyFee; }
        void stage(String s) { stage = s; }

        // Base portion = days * daily fee.
        double baseAmount() { return totalDays * dailyFee; }

        // Rands with space thousands separator and 2 decimals.
        static String rands(double v) {
            DecimalFormat df = new DecimalFormat("#,##0.00");
            return "R" + df.format(v).replace(",", " ");
        }

        abstract double total();
        abstract String urgency();
        abstract String category();
        abstract String attributes();
    }

    // Injured: base + veterinary + R5 000 if operation required.
    // Urgency: Critical if operation AND veterinary >= 12000; High if either;
    //          Medium if veterinary >= 4000; otherwise Low.
    static class Injured extends RescueRecord {

        private String diagnosis;
        private double veterinary;
        private boolean operation;

        Injured(String reference, String animal, String species, String region, String ranger,
                int totalDays, double dailyFee, String stage,
                String diagnosis, double veterinary, boolean operation) {
            super(reference, animal, species, region, ranger, totalDays, dailyFee, stage);
            this.diagnosis = diagnosis;
            this.veterinary = veterinary;
            this.operation = operation;
        }

        String diagnosis()    { return diagnosis; }
        double veterinary()   { return veterinary; }
        boolean operation()   { return operation; }

        @Override double total() {
            return baseAmount() + veterinary + (operation ? 5000.0 : 0.0);
        }

        @Override String urgency() {
            if (operation && veterinary >= 12000) return "Critical";
            if (operation || veterinary >= 12000) return "High";
            if (veterinary >= 4000)               return "Medium";
            return "Low";
        }

        @Override String category() { return "Injured Animal Rescue"; }

        @Override String attributes() {
            return "Diagnosis             : " + diagnosis + "\n" +
                   "Veterinary Cost       : " + rands(veterinary) + "\n" +
                   "Operation             : " + (operation ? "Yes" : "No");
        }

        @Override public void begin() { stage(ACTIVE); }
        @Override public void close() { stage(CLOSED); }

        @Override public String overview() {
            return "Case ID           : " + reference() + "\n" +
                   "Type              : " + category() + "\n" +
                   "Species           : " + species() + "\n" +
                   "Ranger            : " + ranger() + "\n" +
                   "Priority          : " + urgency() + "\n" +
                   "Status            : " + stage() + "\n" +
                   "Total Cost        : " + rands(total());
        }
    }

    // Orphaned: base + feeding + R2 500 if foster care required.
    // Urgency: Critical if age <= 2 AND foster; High if either;
    //          Medium if age <= 9; otherwise Low.
    static class Orphaned extends RescueRecord {

        private int age;
        private double feeding;
        private boolean foster;

        Orphaned(String reference, String animal, String species, String region, String ranger,
                 int totalDays, double dailyFee, String stage,
                 int age, double feeding, boolean foster) {
            super(reference, animal, species, region, ranger, totalDays, dailyFee, stage);
            this.age = age;
            this.feeding = feeding;
            this.foster = foster;
        }

        int age()          { return age; }
        double feeding()   { return feeding; }
        boolean foster()   { return foster; }

        @Override double total() {
            return baseAmount() + feeding + (foster ? 2500.0 : 0.0);
        }

        @Override String urgency() {
            if (age <= 2 && foster) return "Critical";
            if (age <= 2 || foster) return "High";
            if (age <= 9)           return "Medium";
            return "Low";
        }

        @Override String category() { return "Orphaned Animal Rescue"; }

        @Override String attributes() {
            return "Estimated Age (m)     : " + age + "\n" +
                   "Feeding Cost          : " + rands(feeding) + "\n" +
                   "Foster Care           : " + (foster ? "Yes" : "No");
        }

        @Override public void begin() { stage(ACTIVE); }
        @Override public void close() { stage(CLOSED); }

        @Override public String overview() {
            return "Case ID           : " + reference() + "\n" +
                   "Type              : " + category() + "\n" +
                   "Species           : " + species() + "\n" +
                   "Ranger            : " + ranger() + "\n" +
                   "Priority          : " + urgency() + "\n" +
                   "Status            : " + stage() + "\n" +
                   "Total Cost        : " + rands(total());
        }
    }

    // Endangered: base + security + R8 000 if specialist team required.
    // Urgency: Critical if team AND critically endangered; High if either;
    //          Medium if endangered; otherwise Low.
    static class Endangered extends RescueRecord {

        private String redList;
        private double security;
        private boolean specialist;

        Endangered(String reference, String animal, String species, String region, String ranger,
                   int totalDays, double dailyFee, String stage,
                   String redList, double security, boolean specialist) {
            super(reference, animal, species, region, ranger, totalDays, dailyFee, stage);
            this.redList = redList;
            this.security = security;
            this.specialist = specialist;
        }

        String redList()     { return redList; }
        double security()    { return security; }
        boolean specialist() { return specialist; }

        @Override double total() {
            return baseAmount() + security + (specialist ? 8000.0 : 0.0);
        }

        @Override String urgency() {
            boolean critical = "Critically Endangered".equalsIgnoreCase(redList);
            if (specialist && critical) return "Critical";
            if (specialist || critical) return "High";
            if ("Endangered".equalsIgnoreCase(redList)) return "Medium";
            return "Low";
        }

        @Override String category() { return "Endangered Species Rescue"; }

        @Override String attributes() {
            return "Red List              : " + redList + "\n" +
                   "Security Cost         : " + rands(security) + "\n" +
                   "Specialist Team       : " + (specialist ? "Yes" : "No");
        }

        @Override public void begin() { stage(ACTIVE); }
        @Override public void close() { stage(CLOSED); }

        @Override public String overview() {
            return "Case ID           : " + reference() + "\n" +
                   "Type              : " + category() + "\n" +
                   "Species           : " + species() + "\n" +
                   "Ranger            : " + ranger() + "\n" +
                   "Priority          : " + urgency() + "\n" +
                   "Status            : " + stage() + "\n" +
                   "Total Cost        : " + rands(total());
        }
    }

    // Business layer: stores all records in an ArrayList and enforces unique IDs.
    static class Registry {

        private final ArrayList<RescueRecord> records = new ArrayList<>();

        void store(RescueRecord rr) {
            if (rr == null) throw new IllegalArgumentException("Record cannot be null.");
            String id = rr.reference();
            if (id == null || id.trim().isEmpty())
                throw new IllegalArgumentException("Case ID cannot be blank.");
            if (lookup(id) != null)
                throw new IllegalArgumentException("Case ID already exists: " + id);
            records.add(rr);
        }

        RescueRecord lookup(String id) {
            if (id == null) return null;
            for (RescueRecord rr : records)
                if (rr.reference().equalsIgnoreCase(id.trim())) return rr;
            return null;
        }

        boolean switchStage(String id, String stage) {
            RescueRecord rr = lookup(id);
            if (rr == null) return false;
            rr.stage(stage);
            return true;
        }

        ArrayList<RescueRecord> records() { return records; }
        int size() { return records.size(); }

        double grandSum() {
            double t = 0;
            for (RescueRecord rr : records) t += rr.total();
            return t;
        }

        boolean contains(String id) { return lookup(id) != null; }
    }

    // JOptionPane user interface.
    static class Console {

        private static final Registry registry = new Registry();

        static void begin() {
            boolean live = true;
            while (live) {
                String title =
                        "=====================================\n" +
                        "WILDLIFE RESCUE OPERATIONS SYSTEM\n" +
                        "=====================================\n" +
                        "1. Create Rescue Case\n" +
                        "2. Search Rescue Case\n" +
                        "3. Update Rescue Status\n" +
                        "4. Display All Rescue Cases\n" +
                        "5. Rescue Report\n" +
                        "6. Exit\n" +
                        "=====================================\n" +
                        "Select an option:";

                String chosen = JOptionPane.showInputDialog(null, title, "WildLife SA", JOptionPane.PLAIN_MESSAGE);
                if (chosen == null) { live = false; continue; }

                switch (chosen.trim()) {
                    case "1": makeRecord();  break;
                    case "2": findRecord();  break;
                    case "3": moveStage();   break;
                    case "4": listAll();     break;
                    case "5": showReport();  break;
                    case "6": live = false; message("Goodbye."); break;
                    default:  message("Invalid choice. Enter 1 to 6.");
                }
            }
        }

        private static void makeRecord() {
            String[] types = {
                "Injured Animal Rescue",
                "Orphaned Animal Rescue",
                "Endangered Species Rescue"
            };
            String pick = (String) JOptionPane.showInputDialog(
                    null, "Select rescue type:", "WildLife SA",
                    JOptionPane.QUESTION_MESSAGE, null, types, types[0]);
            if (pick == null) return;

            String id = ask("Enter Rescue Case ID:");
            if (id == null) return;
            if (registry.contains(id)) { message("ID already in use."); return; }

            String animal  = ask("Enter Animal Name:");      if (animal == null) return;
            String species = ask("Enter Species:");          if (species == null) return;
            String region  = ask("Enter Rescue Location:");  if (region == null) return;
            String ranger  = ask("Enter Assigned Ranger:");  if (ranger == null) return;
            Integer days   = askInt("Enter Number of Rescue Days:"); if (days == null) return;
            Double fee     = askDouble("Enter Daily Care Cost (R):"); if (fee == null) return;

            try {
                RescueRecord rr;
                if (pick.equals(types[0])) {
                    String diag = ask("Enter Injury Description:");          if (diag == null) return;
                    Double vet  = askAmount("Veterinary Treatment Cost (R):"); if (vet == null) return;
                    boolean op  = confirm("Is Surgery Required?");
                    rr = new Injured(id, animal, species, region, ranger, days, fee, Lifecycle.OPENED, diag, vet, op);
                } else if (pick.equals(types[1])) {
                    Integer age = askInt("Enter Estimated Age (Months):"); if (age == null) return;
                    Double feed = askAmount("Feeding Cost (R):");          if (feed == null) return;
                    boolean foster = confirm("Is Foster Care Required?");
                    rr = new Orphaned(id, animal, species, region, ranger, days, fee, Lifecycle.OPENED, age, feed, foster);
                } else {
                    String list = ask("Enter Conservation Classification:"); if (list == null) return;
                    Double sec  = askAmount("Security Cost (R):");           if (sec == null) return;
                    boolean team = confirm("Is a Specialist Team Required?");
                    rr = new Endangered(id, animal, species, region, ranger, days, fee, Lifecycle.OPENED, list, sec, team);
                }
                registry.store(rr);
                message("Case created.\n\n" + rr.overview());
            } catch (IllegalArgumentException ex) {
                message(ex.getMessage());
            }
        }

        private static void findRecord() {
            String id = ask("Enter Rescue Case ID to search:");
            if (id == null) return;
            RescueRecord rr = registry.lookup(id);
            if (rr == null) { message("Not found: " + id); return; }
            showPanel("Rescue Case Details", detailed(rr));
        }

        private static void moveStage() {
            String id = ask("Enter Rescue Case ID to update:");
            if (id == null) return;
            RescueRecord rr = registry.lookup(id);
            if (rr == null) { message("Not found: " + id); return; }

            String[] stages = { Lifecycle.ACTIVE, Lifecycle.WATCH, Lifecycle.CLOSED, Lifecycle.OPENED };
            String next = (String) JOptionPane.showInputDialog(
                    null, "New status for " + rr.reference() + ":",
                    "Update Status", JOptionPane.QUESTION_MESSAGE,
                    null, stages, rr.stage());
            if (next == null) return;

            registry.switchStage(id, next);
            message("Status updated.\n\n" + rr.overview());
        }

        private static void listAll() {
            ArrayList<RescueRecord> list = registry.records();
            if (list.isEmpty()) { message("No rescue cases yet."); return; }

            StringBuilder sb = new StringBuilder();
            sb.append("ALL RESCUE CASES (").append(list.size()).append(")\n");
            sb.append("=====================================\n");
            for (RescueRecord rr : list) {
                sb.append(detailed(rr)).append("\n-------------------------------------\n");
            }
            showPanel("All Rescue Cases", sb.toString());
        }

        private static void showReport() {
            ArrayList<RescueRecord> list = registry.records();
            StringBuilder sb = new StringBuilder();
            sb.append("=====================================\n");
            sb.append("WILDLIFE RESCUE REPORT\n");
            sb.append("=====================================\n");

            if (list.isEmpty()) {
                sb.append("No rescue cases to report.\n");
            } else {
                for (RescueRecord rr : list) {
                    sb.append("Case ID          : ").append(rr.reference()).append("\n");
                    sb.append("Type             : ").append(rr.category()).append("\n");
                    sb.append("Species          : ").append(rr.species()).append("\n");
                    sb.append("Location         : ").append(rr.region()).append("\n");
                    sb.append("Ranger           : ").append(rr.ranger()).append("\n");
                    sb.append("Priority         : ").append(rr.urgency()).append("\n");
                    sb.append("Status           : ").append(rr.stage()).append("\n");
                    sb.append("Total Cost       : ").append(RescueRecord.rands(rr.total())).append("\n");
                    sb.append("-------------------------------------\n");
                }
            }
            sb.append("=====================================\n");
            sb.append("Total Cases      : ").append(registry.size()).append("\n");
            sb.append("Total Cost       : ").append(RescueRecord.rands(registry.grandSum())).append("\n");
            sb.append("=====================================\n");
            showPanel("Wildlife Rescue Report", sb.toString());
        }

        private static String detailed(RescueRecord rr) {
            return "Case ID           : " + rr.reference() + "\n" +
                   "Animal Name       : " + rr.animal() + "\n" +
                   "Type              : " + rr.category() + "\n" +
                   "Species           : " + rr.species() + "\n" +
                   "Location          : " + rr.region() + "\n" +
                   "Ranger            : " + rr.ranger() + "\n" +
                   "Days              : " + rr.totalDays() + "\n" +
                   "Daily Cost        : " + RescueRecord.rands(rr.dailyFee()) + "\n" +
                   "Status            : " + rr.stage() + "\n" +
                   "Priority          : " + rr.urgency() + "\n" +
                   rr.attributes() + "\n" +
                   "Total Cost        : " + RescueRecord.rands(rr.total()) + "\n";
        }

        private static void showPanel(String title, String body) {
            JTextArea area = new JTextArea(body);
            area.setEditable(false);
            area.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(560, 440));
            JOptionPane.showMessageDialog(null, scroll, title, JOptionPane.INFORMATION_MESSAGE);
        }

        // --- input helpers ---

        private static String ask(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                if (!s.trim().isEmpty()) return s.trim();
                message("Cannot be blank.");
            }
        }

        private static Integer askInt(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    int v = Integer.parseInt(s.trim());
                    if (v > 0) return v;
                    message("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    message("Enter a whole number.");
                }
            }
        }

        private static Double askDouble(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v > 0) return v;
                    message("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    message("Enter a number.");
                }
            }
        }

        private static Double askAmount(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v >= 0) return v;
                    message("Cannot be negative.");
                } catch (NumberFormatException e) {
                    message("Enter a number.");
                }
            }
        }

        private static boolean confirm(String prompt) {
            return JOptionPane.showConfirmDialog(null, prompt, "WildLife SA",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
        }

        private static void message(String msg) {
            JOptionPane.showMessageDialog(null, msg, "WildLife SA", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}