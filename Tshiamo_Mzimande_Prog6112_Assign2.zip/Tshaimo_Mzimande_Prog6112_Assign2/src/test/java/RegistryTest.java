package com.mycompany.tshaimo_mzimande_prog6112_assign2;

import com.mycompany.tshaimo_mzimande_prog6112_assign2.Tshaimo_Mzimande_Prog6112_Assign2.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RegistryTest {

    private Registry registry;

    @BeforeEach
    public void setUp() {
        registry = new Registry();
    }

    // ---- cost calculations ----

    @Test public void injuredNoOperation() {
        Injured i = new Injured("R01", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, Lifecycle.OPENED, "Snare wound", 8500, false);
        assertEquals(18500, i.total(), 0.001);
    }

    @Test public void injuredWithOperation() {
        Injured i = new Injured("R02", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, Lifecycle.OPENED, "Snare wound", 8500, true);
        assertEquals(23500, i.total(), 0.001);
    }

    @Test public void orphanedNoFoster() {
        Orphaned o = new Orphaned("R03", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, Lifecycle.OPENED, 4, 3000, false);
        assertEquals(9000, o.total(), 0.001);
    }

    @Test public void orphanedWithFoster() {
        Orphaned o = new Orphaned("R04", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, Lifecycle.OPENED, 4, 3000, true);
        assertEquals(11500, o.total(), 0.001);
    }

    @Test public void endangeredNoTeam() {
        Endangered e = new Endangered("R05", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, Lifecycle.OPENED, "Critically Endangered", 12000, false);
        assertEquals(17600, e.total(), 0.001);
    }

    @Test public void endangeredWithTeam() {
        Endangered e = new Endangered("R06", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, Lifecycle.OPENED, "Critically Endangered", 12000, true);
        assertEquals(25600, e.total(), 0.001);
    }

    // ---- priority tiers ----

    @Test public void injuredCritical() {
        Injured i = new Injured("R07", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Lifecycle.OPENED, "Gunshot", 15000, true);
        assertEquals("Critical", i.urgency());
    }

    @Test public void injuredHigh() {
        Injured i = new Injured("R08", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Lifecycle.OPENED, "Fracture", 13000, false);
        assertEquals("High", i.urgency());
    }

    @Test public void injuredMedium() {
        Injured i = new Injured("R09", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Lifecycle.OPENED, "Wound", 5000, false);
        assertEquals("Medium", i.urgency());
    }

    @Test public void injuredLow() {
        Injured i = new Injured("R10", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Lifecycle.OPENED, "Cut", 1000, false);
        assertEquals("Low", i.urgency());
    }

    @Test public void orphanedCritical() {
        Orphaned o = new Orphaned("R11", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, Lifecycle.OPENED, 2, 3000, true);
        assertEquals("Critical", o.urgency());
    }

    @Test public void orphanedHigh() {
        Orphaned o = new Orphaned("R12", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, Lifecycle.OPENED, 2, 3000, false);
        assertEquals("High", o.urgency());
    }

    @Test public void orphanedMedium() {
        Orphaned o = new Orphaned("R13", "Young Elephant", "African Elephant", "Addo", "E",
                5, 400, Lifecycle.OPENED, 8, 3000, false);
        assertEquals("Medium", o.urgency());
    }

    @Test public void orphanedLow() {
        Orphaned o = new Orphaned("R14", "Juvenile", "African Elephant", "Addo", "E",
                5, 400, Lifecycle.OPENED, 18, 3000, false);
        assertEquals("Low", o.urgency());
    }

    @Test public void endangeredCritical() {
        Endangered e = new Endangered("R15", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Lifecycle.OPENED, "Critically Endangered", 9000, true);
        assertEquals("Critical", e.urgency());
    }

    @Test public void endangeredHigh() {
        Endangered e = new Endangered("R16", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Lifecycle.OPENED, "Critically Endangered", 9000, false);
        assertEquals("High", e.urgency());
    }

    @Test public void endangeredMedium() {
        Endangered e = new Endangered("R17", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Lifecycle.OPENED, "Endangered", 9000, false);
        assertEquals("Medium", e.urgency());
    }

    @Test public void endangeredLow() {
        Endangered e = new Endangered("R18", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Lifecycle.OPENED, "Vulnerable", 9000, false);
        assertEquals("Low", e.urgency());
    }

    // ---- status transitions ----

    @Test public void beginSetsActive() {
        Injured i = new Injured("R19", "Zebra", "Plains Zebra", "Etosha", "G",
                4, 150, Lifecycle.OPENED, "Sprain", 1200, false);
        i.begin();
        assertEquals(Lifecycle.ACTIVE, i.stage());
    }

    @Test public void closeSetsClosed() {
        Orphaned o = new Orphaned("R20", "Baby Giraffe", "Giraffe", "Etosha", "G",
                4, 150, Lifecycle.OPENED, 4, 800, false);
        o.close();
        assertEquals(Lifecycle.CLOSED, o.stage());
    }

    // ---- search ----

    @Test public void findExisting() {
        Injured i = new Injured("R21", "Leopard", "African Leopard", "Sabie", "H",
                2, 250, Lifecycle.OPENED, "Snare", 3000, false);
        registry.store(i);
        assertNotNull(registry.lookup("R21"));
        assertEquals("Leopard", registry.lookup("R21").animal());
    }

    @Test public void findMissing() {
        assertNull(registry.lookup("R999"));
    }

    @Test public void findCaseInsensitive() {
        Orphaned o = new Orphaned("r22", "Baby Lion", "African Lion", "Kgalagadi", "I",
                3, 200, Lifecycle.OPENED, 2, 900, true);
        registry.store(o);
        assertNotNull(registry.lookup("R22"));
    }

    // ---- duplicates and validation ----

    @Test public void rejectDuplicate() {
        registry.store(new Injured("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, Lifecycle.OPENED, "Horn", 2500, false));
        Injured clash = new Injured("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, Lifecycle.OPENED, "Horn", 2500, false);
        assertThrows(IllegalArgumentException.class, () -> registry.store(clash));
    }

    @Test public void rejectDuplicateCaseInsensitive() {
        registry.store(new Endangered("R24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, Lifecycle.OPENED, "Endangered", 3000, false));
        Endangered clash = new Endangered("r24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, Lifecycle.OPENED, "Endangered", 3000, false);
        assertThrows(IllegalArgumentException.class, () -> registry.store(clash));
    }

    @Test public void rejectBlankId() {
        Injured i = new Injured("   ", "Bird", "Eagle", "Drakensberg", "L",
                2, 100, Lifecycle.OPENED, "Wing", 500, false);
        assertThrows(IllegalArgumentException.class, () -> registry.store(i));
    }

    @Test public void rejectNull() {
        assertThrows(IllegalArgumentException.class, () -> registry.store(null));
    }

    // ---- totals ----

    @Test public void totalsAcrossTwoRecords() {
        registry.store(new Injured("R25", "Elephant", "African Elephant", "Kruger", "A",
                5, 100, Lifecycle.OPENED, "Leg", 2000, false)); // 2500
        registry.store(new Orphaned("R26", "Baby Rhino", "White Rhino", "Hluhluwe", "B",
                10, 200, Lifecycle.OPENED, 6, 1500, true)); // 6000

        assertEquals(2, registry.size());
        assertEquals(8500, registry.grandSum(), 0.001);
    }
}